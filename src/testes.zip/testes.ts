import NFeWizard from './classes/NFeWizard.js';
import { format } from 'date-fns-tz';
import { Cancelamento, CartaDeCorrecao, CienciaDaOperacao, ConfirmacaoDaOperacao, ConsultaNFe, DesconhecimentoDaOperacao, EventoNFe, InutilizacaoData, LayoutNFe, NFe, NFeDanfe, OperacaoNaoRealizada } from '@Protocols';
import path from 'path';

const __filename = new URL(import.meta.url).pathname;
const __dirname = path.dirname(__filename);

const callNFEjs = async () => {
    const nfeWizard = new NFeWizard();



    // Inicializa a Lib NFeWizardJS

    // CNPJ INTERSOLID
    // certificado_intersolid
    // 06319316000127
    // 123456

    // CNPJ KONVIX
    // 41279085000176
    // 12345678

    // CNPJ JUSSARA
    // certificado_jussara
    // 08819185000172
    // 1234
    await nfeWizard.NFE_LoadEnvironment({
        config: {
            dfe: {
                baixarXMLDistribuicao: true,
                pathXMLDistribuicao: "tmp/DistribuicaoDFe",
                armazenarXMLAutorizacao: true,
                pathXMLAutorizacao: "tmp/Autorizacao",
                armazenarXMLRetorno: true,
                pathXMLRetorno: "tmp/RequestLogs",
                armazenarXMLConsulta: true,
                pathXMLConsulta: "tmp/RequestLogs",
                armazenarXMLConsultaComTagSoap: false,
                armazenarRetornoEmJSON: false,
                pathRetornoEmJSON: "tmp/DistribuicaoDFe",

                pathCertificado: "certificado.pfx",
                senhaCertificado: "1234",
                UF: "SP",
                CPFCNPJ: "08819185000172",
            },
            nfe: {
                ambiente: 2,
                versaoDF: "4.00",
            },
            email: {
                host: 'mail.konvix.com.br', // Substitua pelo host SMTP do seu provedor de e-mail
                port: 465, // 587 para TLS ou 465 para SSL
                secure: true, // true para 465, false para outros
                auth: {
                    user: 'marco.lima@konvix.com.br', // Seu e-mail
                    pass: 'MaurelioKV98@!#$' // Sua senha
                },
                emailParams: {
                    from: 'Konvix <noreply.konvix@gmail.com>', // Remetente padrão
                    to: 'marco.lima@konvix.com.br', // Destinatário padrão
                }
            },
            lib: {
                connection: {
                    timeout: 30000,
                },
                log: {
                    exibirLogNoConsole: true,
                }
            }
        }
    });

    const nfe: NFe = {
        indSinc: 0,
        idLote: 1,
        NFe: [
            {
                infNFe: {
                    ide: {
                        cUF: 35,
                        cNF: '65083162',
                        natOp: "VENDA DE MERCADORIA",
                        mod: 55,
                        serie: '1',
                        nNF: 145238062,
                        dhEmi: "2024-08-01T00:00:00-03:00",
                        tpNF: 1,
                        idDest: 1,
                        cMunFG: 3502804,
                        tpImp: 1,
                        tpEmis: 1,
                        cDV: 0,
                        tpAmb: 2,
                        finNFe: 1,
                        indFinal: 1,
                        indPres: 9,
                        indIntermed: 0,
                        procEmi: 0,
                    },
                    emit: {
                        CNPJCPF: '06319316000127',
                        xNome: "INTERSOLID DESENVOLVIMENTO DE SISTEMAS S.A",
                        xFant: "INTERSOLID SOFTWARE",
                        enderEmit: {
                            xLgr: "AVENIDA BRASILIA",
                            nro: '2121',
                            xBairro: "JARDIM NOVA YORQUE",
                            cMun: 3502804,
                            xMun: "ARACATUBA",
                            UF: "SP",
                            CEP: '16018000',
                            cPais: 1058,
                            xPais: "BRASIL",
                            fone: "12991595173",
                        },
                        IE: "330086449118",
                        CRT: 3
                    },
                    dest: {
                        CNPJCPF: '08819185000172',
                        xNome: "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                        enderDest: {
                            xLgr: "R MARCO MANFRINATI",
                            nro: "1285",
                            xBairro: "JARDIM JUSSARA",
                            cMun: 3502804,
                            xMun: "ARACATUBA",
                            UF: "SP",
                            CEP: '16021350',
                            cPais: 1058,
                            xPais: "BRASIL",
                            fone: "1896880781"
                        },
                        indIEDest: 1,
                        IE: "177260230119"
                    },

                    det: [
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "QUEIJO MUSSARELA 4,0 KG (6 X 4)",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                    ],
                    total: {
                        ICMSTot: {
                            vBC: "845.13",
                            vICMS: "101.42",
                            vICMSDeson: "0.00",
                            vFCP: "0.00",
                            vBCST: "0.00",
                            vST: "0.00",
                            vFCPST: "0.00",
                            vFCPSTRet: "0.00",
                            vProd: "845.13",
                            vFrete: "0.00",
                            vSeg: "0.00",
                            vDesc: "0.00",
                            vII: "0.00",
                            vIPI: "0.00",
                            vIPIDevol: "0.00",
                            vPIS: "0.00",
                            vCOFINS: "0.00",
                            vOutro: "0.00",
                            vNF: "845.13",
                            // vTotTrib: "157.02",
                        }
                    },
                    transp: {
                        modFrete: 0,
                        vol: [
                            {
                                qVol: 1,
                                esp: "CAIXA(S)",
                                marca: "DAVACA",
                                pesoL: "24.930",
                                pesoB: "24.930"
                            }
                        ]
                    },
                    pag: {
                        detPag: [
                            {
                                indPag: 1,
                                tPag: 99,
                                xPag: "Outros",
                                vPag: "845.13"
                            }
                        ]
                    },
                },
            },
        ],
    };

    const nfce: NFe = {
        indSinc: 1,
        idLote: 1,
        NFe: [
            {
                infNFe: {
                    ide: {
                        cUF: 35,
                        cNF: '65083161',
                        natOp: "VENDA DE MERCADORIA",
                        mod: 65,
                        serie: '1',
                        nNF: 145238061,
                        dhEmi: "2024-08-09T17:14:00-03:00",
                        tpNF: 1,
                        idDest: 1,
                        cMunFG: 3502804,
                        tpImp: 4,
                        tpEmis: 1,
                        cDV: 0,
                        tpAmb: 2,
                        finNFe: 1,
                        indFinal: 1,
                        indPres: 1,
                        indIntermed: 0,
                        procEmi: 0,
                        verProc: '0.0.9',
                        // dhCont: '2024-08-06T13:54:03-03:00',
                        // xJust: 'Testes de emissão NFCe'
                    },
                    emit: {
                        CNPJCPF: '08819185000172',
                        xNome: "KAWAMOTO & SUGUIMOTO LTDA",
                        xFant: "Não Disponível",
                        enderEmit: {
                            xLgr: "R MARCO MANFRINATI",
                            nro: "1285",
                            xBairro: "JARDIM JUSSARA",
                            cMun: 3502804,
                            xMun: "ARACATUBA",
                            UF: "SP",
                            CEP: '16021350',
                            cPais: 1058,
                            xPais: "BRASIL",
                            fone: "1896880781"
                        },
                        IE: "177260230119", // Presume-se que a Inscrição Estadual do novo emitente permaneça igual, ajuste conforme necessário
                        CRT: 3
                    },
                    dest: {
                        CNPJCPF: '06319316000127',
                        xNome: "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                        enderDest: {
                            xLgr: "AVENIDA BRASILIA",
                            nro: '2121',
                            xBairro: "JARDIM NOVA YORQUE",
                            cMun: 3502804,
                            xMun: "ARACATUBA",
                            UF: "SP",
                            CEP: '16018000',
                            cPais: 1058,
                            xPais: "BRASIL",
                            fone: "12991595173"
                        },
                        indIEDest: 9,
                    },
                    det: [
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                        {
                            prod: {
                                cProd: "00013607",
                                cEAN: "7897318535408",
                                xProd: "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL",
                                NCM: "04061010",
                                EXTIPI: "00",
                                CFOP: 5102,
                                uCom: "KG",
                                qCom: 24.93,
                                vUnCom: "33.9",
                                vProd: "845.13",
                                cEANTrib: "7897318535408",
                                uTrib: "KG",
                                qTrib: 24.93,
                                vUnTrib: "33.9",
                                indTot: 1,
                            },
                            imposto: {
                                ICMS: {
                                    ICMS00: {
                                        orig: 0,
                                        CST: "00",
                                        modBC: 3,
                                        vBC: "845.13",
                                        pICMS: "12.00",
                                        vICMS: "101.42"
                                    }
                                },
                                PIS: {
                                    PISNT: {
                                        CST: "06",
                                    }
                                },
                                COFINS: {
                                    COFINSNT: {
                                        CST: "06",
                                    }
                                }
                            },
                        },
                    ],
                    total: {
                        ICMSTot: {
                            vBC: "845.13",
                            vICMS: "101.42",
                            vICMSDeson: "0.00",
                            vFCP: "0.00",
                            vBCST: "0.00",
                            vST: "0.00",
                            vFCPST: "0.00",
                            vFCPSTRet: "0.00",
                            vProd: "845.13",
                            vFrete: "0.00",
                            vSeg: "0.00",
                            vDesc: "0.00",
                            vII: "0.00",
                            vIPI: "0.00",
                            vIPIDevol: "0.00",
                            vPIS: "0.00",
                            vCOFINS: "0.00",
                            vOutro: "0.00",
                            vNF: "845.13",
                            // vTotTrib: "157.02",
                        }
                    },
                    transp: {
                        modFrete: 9,
                    },
                    pag: {
                        detPag: [
                            {
                                indPag: 1,
                                tPag: 99,
                                xPag: "Outros",
                                vPag: "845.13"
                            }
                        ]
                    },
                },
                infNFeSupl: {
                    qrCode: 'https://www.homologacao.nfce.fazenda.sp.gov.br/qrcode?p=NFe35240808819185000172650011452380619650831611|2|2|1|49f93ae0071a511388510ea51e01a6f111fbc9fc',
                    urlChave: 'https://www.homologacao.nfce.fazenda.sp.gov.br/consulta',
                }
            },
        ],
    };

    // await nfeWizard.NFE_ConsultaStatusServico()
    // const retorno = await nfeWizard.NFE_Autorizacao(nfe)
    // const retorno2 = await nfeWizard.NFCE_Autorizacao(nfce)

    await nfeWizard.NFCE_GerarDanfe({
        chave: '99999999999999999999999999999999999999999999',
        data: nfce,
        outputPath: 'src/assets/DANFE_NFCE.pdf',
    })


}

callNFEjs();